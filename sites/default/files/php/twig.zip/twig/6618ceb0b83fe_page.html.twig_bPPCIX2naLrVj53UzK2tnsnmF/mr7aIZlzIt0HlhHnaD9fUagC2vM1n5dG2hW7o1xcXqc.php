<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/evolve/templates/page.html.twig */
class __TwigTemplate_954fa9f1601cc1019510763ddd0022da extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "

<!DOCTYPE html>
<html lang=\"en\">

<head>
\t<title>Doctor Profile</title>
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
\t<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js\"></script>
\t<script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js\"></script>
\t<link href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css\" rel=\"stylesheet\" />
\t<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css\"/>
\t<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css\"/>
</head>

<body>

\t<section id=\"sec1\">

\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-lg-7 col-md-7 intro-box order-lg-1 order-sm-2\">
\t\t\t\t\t<h1 class=\"fs-1\">Professor Hedley Emsley</h1>
\t\t\t\t\t<p class=\"title\">Neurologist in Preston & Lancaster </p>
\t\t\t\t\t<p style=\"margin-top: -10px;\">MBBS (AIMS), MD, DM </p>
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-sm-7\">
\t\t\t\t\t\t\t<button class=\"btn appbtn rounded-pill mb-2\">Make an appointment</button>
\t\t\t\t\t\t\t<p class=\"pt-4 fs-6 mb-4\">1-800-1234-567 <br>mail@demolink.org</p>
\t\t\t\t\t\t\t<div class=\"rating float-start mb-5\" id=\"rating\">
\t\t\t\t\t\t\t\t<span class=\"star\" data-value=\"1\">&#9733;</span>
\t\t\t\t\t\t\t\t<span class=\"star\" data-value=\"2\">&#9733;</span>
\t\t\t\t\t\t\t\t<span class=\"star\" data-value=\"3\">&#9733;</span>
\t\t\t\t\t\t\t\t<span class=\"star\" data-value=\"4\">&#9733;</span>
\t\t\t\t\t\t\t\t<span class=\"star\" data-value=\"5\">&#9733;</span>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-sm-5\">
\t\t\t\t\t\t\t<button class=\"whatsappbtn btn mb-2\"><span><i class=\"fa-brands fa-whatsapp mx-1\"></i> </span> <span class=\"line\"></span> <span class=\"mx-2 fw-bolder\">SHARE</span></button>
\t\t\t\t\t\t\t<p class=\"exp mt-3\"><span class=\"ten\">10+ Years</span></p>
\t\t\t\t\t\t\t<p class=\"fs-5 fw-bold mx-1 mb-4\" style=\"margin-top: -30px;\"><span class=\"ex\">Experience</span></p>
\t\t\t\t\t\t\t<p class=\"exp mb-4\"><span class=\"ten\">12k+</span> Patients</p>

\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"col-sm-4 mt-2 mb-2\">
\t\t\t\t\t\t\t<img class=\"img-fluid\" src=\"themes/custom/evolve/images/logo1.png\" alt=\"\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-sm-4 mt-2 mb-2\">
\t\t\t\t\t\t\t<img class=\"img-fluid\" src=\"themes/custom/evolve/images/logo2.png\" alt=\"\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-sm-4 mt-2 mb-2\">
\t\t\t\t\t\t\t<img class=\"img-fluid\" src=\"themes/custom/evolve/images/logo3.png\" alt=\"\">
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t\t<div class=\"col-lg-4 offset-lg-1 col-md-5 order-sm-1 order-lg-2\">
\t\t\t\t\t<img class=\"img-fluid float-end docimg\" src=\"themes/custom/evolve/images/docimg.png\" alt=\"\">
\t\t\t\t</div>

                
\t\t\t</div>
\t\t</div>
\t\t

\t</section>


\t<section id=\"sec2\" class=\"pt-5 pb-5\">
\t\t<div class=\"container\">
\t\t\t<ul class=\"nav nav-pills\" role=\"tablist\">
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link active fw-bold\" data-bs-toggle=\"pill\" href=\"#overview\">Overview</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link fw-bold\" data-bs-toggle=\"pill\" href=\"#speciality\">Speciality</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link fw-bold\" data-bs-toggle=\"pill\" href=\"#summary\">Expertise summary</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link fw-bold\" data-bs-toggle=\"pill\" href=\"#practise\">Places of practise</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link fw-bold\" data-bs-toggle=\"pill\" href=\"#meet\">First available time to meet </a>
\t\t\t\t</li>
\t\t\t</ul>
\t\t</div>

\t\t<div class=\"container\">
\t\t\t<div class=\"tab-content\">

\t\t\t\t<div id=\"overview\" class=\"container tab-pane active pt-4\"><br>
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-lg-7 col-sm-7 pilltext\">
\t\t\t\t\t\t\t<p>As SANA Medical Center President and CMO since 1997, Scott Riley is an
\t\t\t\t\t\t\t\tactive member in the San Diego County community. He currently serves
\t\t\t\t\t\t\t\tas the Vice Chair of the Board of Directors for the San Diego Council of
\t\t\t\t\t\t\t\tClinics, a board member of the North San Diego Economic Council, San
\t\t\t\t\t\t\t\tDiegans for Healthcare Coverage, the Blue Shield/UCSF Clinical Leadership
\t\t\t\t\t\t\t\tInstitute, The San Diego Regional Climate Education Partnership, CSUSM
\t\t\t\t\t\t\t\tUniversity Council and the Palomar College President’s Circle. </p>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t<p>Mr. Riley ha</p>
\t\t\t\t\t\t\t<b>Education </b>
\t\t\t\t\t\t\t<p>Perelman School of Medicine at the University of Pennsylvania (1987)</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-5 col-sm-5\">
\t\t\t\t\t\t\t<img class=\"img-fluid\" alt=\"\" src=\"themes/custom/evolve/images/docvid.png\">
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t</div>

\t\t\t\t<div id=\"speciality\" class=\"container tab-pane fade pt-4\"><br>
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-lg-7 col-sm-7 pilltext\">
\t\t\t\t\t\t\t<p>As SANA Medical Center President and CMO since 1997, Scott Riley is an
\t\t\t\t\t\t\t\tactive member in the San Diego County community. He currently serves
\t\t\t\t\t\t\t\tas the Vice Chair of the Board of Directors for the San Diego Council of
\t\t\t\t\t\t\t\tClinics, a board member of the North San Diego Economic Council, San
\t\t\t\t\t\t\t\tDiegans for Healthcare Coverage, the Blue Shield/UCSF Clinical Leadership
\t\t\t\t\t\t\t\tInstitute, The San Diego Regional Climate Education Partnership, CSUSM
\t\t\t\t\t\t\t\tUniversity Council and the Palomar College President’s Circle. </p>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t<p>Mr. Riley ha</p>
\t\t\t\t\t\t\t<b>Education </b>
\t\t\t\t\t\t\t<p>Perelman School of Medicine at the University of Pennsylvania (1987)</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-5 col-sm-5\">
\t\t\t\t\t\t\t<img class=\"img-fluid\" src=\"themes/custom/evolve/images/docvid.png\" alt=\"\">
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div id=\"summary\" class=\"container tab-pane fade pt-4\"><br>
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-lg-7 col-sm-7 pilltext\">
\t\t\t\t\t\t\t<p>As SANA Medical Center President and CMO since 1997, Scott Riley is an
\t\t\t\t\t\t\t\tactive member in the San Diego County community. He currently serves
\t\t\t\t\t\t\t\tas the Vice Chair of the Board of Directors for the San Diego Council of
\t\t\t\t\t\t\t\tClinics, a board member of the North San Diego Economic Council, San
\t\t\t\t\t\t\t\tDiegans for Healthcare Coverage, the Blue Shield/UCSF Clinical Leadership
\t\t\t\t\t\t\t\tInstitute, The San Diego Regional Climate Education Partnership, CSUSM
\t\t\t\t\t\t\t\tUniversity Council and the Palomar College President’s Circle. </p>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t<p>Mr. Riley ha</p>
\t\t\t\t\t\t\t<b>Education </b>
\t\t\t\t\t\t\t<p>Perelman School of Medicine at the University of Pennsylvania (1987)</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-5 col-sm-5\">
\t\t\t\t\t\t\t<img class=\"img-fluid\" src=\"themes/custom/evolve/images/docvid.png\" alt=\"\">
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div id=\"practise\" class=\"container tab-pane fade pt-4\"><br>
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-lg-7 col-sm-7 pilltext\">
\t\t\t\t\t\t\t<p>As SANA Medical Center President and CMO since 1997, Scott Riley is an
\t\t\t\t\t\t\t\tactive member in the San Diego County community. He currently serves
\t\t\t\t\t\t\t\tas the Vice Chair of the Board of Directors for the San Diego Council of
\t\t\t\t\t\t\t\tClinics, a board member of the North San Diego Economic Council, San
\t\t\t\t\t\t\t\tDiegans for Healthcare Coverage, the Blue Shield/UCSF Clinical Leadership
\t\t\t\t\t\t\t\tInstitute, The San Diego Regional Climate Education Partnership, CSUSM
\t\t\t\t\t\t\t\tUniversity Council and the Palomar College President’s Circle. </p>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t<p>Mr. Riley ha</p>
\t\t\t\t\t\t\t<b>Education </b>
\t\t\t\t\t\t\t<p>Perelman School of Medicine at the University of Pennsylvania (1987)</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-5 col-sm-5\">
\t\t\t\t\t\t\t<img class=\"img-fluid\" src=\"themes/custom/evolve/images/docvid.png\" alt=\"\">
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div id=\"meet\" class=\"container tab-pane fade pt-4\"><br>
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-lg-7 col-sm-7 pilltext\">
\t\t\t\t\t\t\t<p>As SANA Medical Center President and CMO since 1997, Scott Riley is an
\t\t\t\t\t\t\t\tactive member in the San Diego County community. He currently serves
\t\t\t\t\t\t\t\tas the Vice Chair of the Board of Directors for the San Diego Council of
\t\t\t\t\t\t\t\tClinics, a board member of the North San Diego Economic Council, San
\t\t\t\t\t\t\t\tDiegans for Healthcare Coverage, the Blue Shield/UCSF Clinical Leadership
\t\t\t\t\t\t\t\tInstitute, The San Diego Regional Climate Education Partnership, CSUSM
\t\t\t\t\t\t\t\tUniversity Council and the Palomar College President’s Circle. </p>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t<p>Mr. Riley ha</p>
\t\t\t\t\t\t\t<b>Education </b>
\t\t\t\t\t\t\t<p>Perelman School of Medicine at the University of Pennsylvania (1987)</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-lg-5 col-sm-5\">
\t\t\t\t\t\t\t<img class=\"img-fluid\" src=\"themes/custom/evolve/images/docvid.png\" alt=\"\">
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t
\t\t\t</div>
\t\t</div>

\t\t<div class=\"container mt-4\">
\t\t\t<div class=\"owl-carousel docslider\">
\t\t\t\t<img src=\"themes/custom/evolve/images/video1.png\" class=\"img-fluid\" alt=\"...\">
\t\t\t\t<img src=\"themes/custom/evolve/images/video2.png\" class=\"img-fluid\" alt=\"...\">
\t\t\t\t<img src=\"themes/custom/evolve/images/video3.png\" class=\"img-fluid\" alt=\"...\">
\t\t\t\t<img src=\"themes/custom/evolve/images/video1.png\" class=\"img-fluid\" alt=\"...\"> 
\t\t\t\t<img src=\"themes/custom/evolve/images/video2.png\" class=\"img-fluid\" alt=\"...\">
\t\t\t  </div>
\t\t</div>
\t</section>


\t<section id=\"sec3\" class=\"p-5 pb-0\">
\t\t<div class=\"container\">
\t\t\t<h2>Book Appointment</h2>
\t\t\t<ul class=\"nav nav-pills pt-3\" role=\"tablist\">
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link active fw-bold\" data-bs-toggle=\"pill\" href=\"#brain\">Advanced Brain Clinic </a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link fw-bold\" data-bs-toggle=\"pill\" href=\"#spine\">Spine Surgical Clinic</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link fw-bold\" data-bs-toggle=\"pill\" href=\"#medical\">Gleneagles Medical Centre Clinic</a>
\t\t\t\t</li>
\t\t\t</ul>


\t\t\t<div id=\"brain\" class=\"container tab-pane active\"><br>
\t\t\t\t<div class=\"col-lg-8 col-sm-12 pt-4\">
\t\t\t\t\t<div class=\"row\">

\t\t\t\t\t\t<div class=\"owl-carousel dateslider\">
\t\t\t\t\t\t\t<div class=\"date-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"day text-center\">MON</div>
\t\t\t\t\t\t\t\t<div class=\"date text-center\">16</div>
\t\t\t\t\t\t\t</div>
\t
\t\t\t\t\t\t\t<div class=\"date-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"day text-center\">Tue</div>
\t\t\t\t\t\t\t\t<div class=\"date text-center\">17</div>
\t\t\t\t\t\t\t</div>
\t
\t\t\t\t\t\t\t<div class=\"date-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"day text-center\">Wed</div>
\t\t\t\t\t\t\t\t<div class=\"date text-center\">18</div>
\t\t\t\t\t\t\t</div>
\t
\t\t\t\t\t\t\t<div class=\"date-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"day text-center\">Thu</div>
\t\t\t\t\t\t\t\t<div class=\"date text-center\">19</div>
\t\t\t\t\t\t\t</div>
\t
\t\t\t\t\t\t\t<div class=\"date-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"day text-center\">Fri</div>
\t\t\t\t\t\t\t\t<div class=\"date text-center\">20</div>
\t\t\t\t\t\t\t</div>
\t
\t\t\t\t\t\t\t<div class=\"date-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"day text-center\">Sat</div>
\t\t\t\t\t\t\t\t<div class=\"date text-center\">21</div>
\t\t\t\t\t\t\t</div>
\t
\t\t\t\t\t\t\t<div class=\"date-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"day text-center\">Sun</div>
\t\t\t\t\t\t\t\t<div class=\"date text-center\">22</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"date-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"day text-center\">Mon</div>
\t\t\t\t\t\t\t\t<div class=\"date text-center\">23</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"date-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"day text-center\">Tue</div>
\t\t\t\t\t\t\t\t<div class=\"date text-center\">24</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t\t<div class=\"row pt-5\">
\t\t\t\t\t<div class=\"col-sm-1 col-lg- \">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/loc.png\" class=\"loc-icon d-block mx-auto\" alt=\"\">
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-sm-5 pt-1\">
\t\t\t\t\t\t\t<p class=\"loctext fw-bold fs-5\">Clinic One <br><span>51 Goldhill Plaza #19-10/12 Banglore 308900</span></p>
\t\t\t\t\t\t\t
\t\t\t\t\t</div>


\t\t\t\t</div>

\t\t\t\t<div class=\"row\">

\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t<div class=\"fs-3 pt-5\"><b>Morning (5 slots)</b></div>
\t\t\t\t\t\t<button class=\"ap-book p-3 mt-2\"><b>9AM - 12 noon </b> <span class=\"text-danger\">No Slot Available</span></button>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t<div class=\"fs-3 pt-5\"><b>After Noon </b></div>
\t\t\t\t\t\t<button class=\"ap-book p-3 mt-2\"><b>12 noon - 5PM </b> <span class=\"text-danger\">Doctor On Leave</span></button>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"fs-3 pt-5\"><b>Evening (5 slots) </b></div>
\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t<button class=\"ap-book p-3 mt-2\"><b>4:00 PM </b></button>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t<button class=\"ap-book p-3 mt-2\"><b>4:30 PM </b></button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t<button class=\"ap-book p-3 mt-2\"><b>5:00 PM </b></button>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t<button class=\"ap-book p-3 mt-2\"><b>4:30 PM </b></button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t<button class=\"ap-book p-3 mt-2\"><b>2:00 PM </b></button>
\t\t\t\t\t\t\t</div>




\t\t\t\t\t\t</div>

\t\t\t\t\t</div>


\t\t\t\t</div>


\t\t\t</div>

\t\t\t<div id=\"spine\" class=\"container tab-pane fade\"><br>
\t\t\t\t<div class=\"col-sm-7\">
\t\t\t\t\t<h3>Spine</h3>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div id=\"medical\" class=\"container tab-pane fade\"><br>
\t\t\t\t<div class=\"col-sm-7\">
\t\t\t\t\t<h3>Medical</h3>
\t\t\t\t</div>
\t\t\t</div>


\t\t</div>
\t</section>

\t<section id=\"sec4\" class=\"pt-0\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row p-2\">
\t\t\t\t<h2 class=\"col-lg-9\">Areas of expertise</h2>
\t\t\t\t<button class=\"btn mx-end col-lg-3 facilities\">View All Speciality Facilities</button>
\t\t\t</div>
\t\t\t<div class=\"row pt-5\">

\t\t\t\t<div class=\"col-lg-4 col-md-6 col-sm-4 p-5\">
\t\t\t\t\t<div class=\"col-sm-4 mx-auto\">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/exp1.png\" width=\"100%\">
\t\t\t\t\t</div>

\t\t\t\t\t<h6 class=\"text-center p-3\"><b>Neurological treatments</b></h6>
\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\tNeurosurgeons, like Neurologists,
\t\t\t\t\t\ttreat a variety of diseases. People
\t\t\t\t\t\twho visit neurosurgeons are
\t\t\t\t\t\tfrequently those who have been
\t\t\t\t\t\trecommended to do so by
\t\t\t\t\t\tneurologists

\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t\t<div class=\"col-lg-4 col-md-6 col-sm-4 p-5\">
\t\t\t\t\t<div class=\"col-sm-4 mx-auto\">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/exp2.png\" width=\"100%\">
\t\t\t\t\t</div>

\t\t\t\t\t<h6 class=\"text-center p-3\"><b>Neurological treatments</b></h6>
\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\tNeurosurgeons, like Neurologists,
\t\t\t\t\t\ttreat a variety of diseases. People
\t\t\t\t\t\twho visit neurosurgeons are
\t\t\t\t\t\tfrequently those who have been
\t\t\t\t\t\trecommended to do so by
\t\t\t\t\t\tneurologists

\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t\t<div class=\"col-lg-4 col-md-6 col-sm-4 p-5\">
\t\t\t\t\t<div class=\"col-sm-4 mx-auto\">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/exp3.png\" width=\"100%\">
\t\t\t\t\t</div>

\t\t\t\t\t<h6 class=\"text-center p-3\"><b>Neurological treatments</b></h6>
\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\tNeurosurgeons, like Neurologists,
\t\t\t\t\t\ttreat a variety of diseases. People
\t\t\t\t\t\twho visit neurosurgeons are
\t\t\t\t\t\tfrequently those who have been
\t\t\t\t\t\trecommended to do so by
\t\t\t\t\t\tneurologists

\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t\t<div class=\"col-lg-4 col-md-6 col-sm-4 p-5\">
\t\t\t\t\t<div class=\"col-sm-4 mx-auto\">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/exp4.png\" width=\"100%\">
\t\t\t\t\t</div>

\t\t\t\t\t<h6 class=\"text-center p-3\"><b>Neurological treatments</b></h6>
\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\tNeurosurgeons, like Neurologists,
\t\t\t\t\t\ttreat a variety of diseases. People
\t\t\t\t\t\twho visit neurosurgeons are
\t\t\t\t\t\tfrequently those who have been
\t\t\t\t\t\trecommended to do so by
\t\t\t\t\t\tneurologists

\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t\t<div class=\"col-lg-4 col-md-6 col-sm-4 p-5\">
\t\t\t\t\t<div class=\"col-sm-4 mx-auto\">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/exp5.png\" width=\"100%\">
\t\t\t\t\t</div>

\t\t\t\t\t<h6 class=\"text-center p-3\"><b>Neurological treatments</b></h6>
\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\tNeurosurgeons, like Neurologists,
\t\t\t\t\t\ttreat a variety of diseases. People
\t\t\t\t\t\twho visit neurosurgeons are
\t\t\t\t\t\tfrequently those who have been
\t\t\t\t\t\trecommended to do so by
\t\t\t\t\t\tneurologists

\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t\t<div class=\"col-lg-4 col-md-6  col-sm-4 p-5\">
\t\t\t\t\t<div class=\"col-sm-4 mx-auto\">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/exp6.png\" width=\"100%\">
\t\t\t\t\t</div>

\t\t\t\t\t<h6 class=\"text-center p-3\"><b>Neurological treatments</b></h6>
\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\tNeurosurgeons, like Neurologists,
\t\t\t\t\t\ttreat a variety of diseases. People
\t\t\t\t\t\twho visit neurosurgeons are
\t\t\t\t\t\tfrequently those who have been
\t\t\t\t\t\trecommended to do so by
\t\t\t\t\t\tneurologists

\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t</div>
\t\t</div>
\t</section>

<section id=\"sec5\" class=\"\">
\t\t<h2 class=\"text-center\">Latest News & Articles</h2>
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-sm-12 search-wrapper p-3\">
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-sm-12 col-md-12\">
\t\t\t\t\t\t\t<div class=\"d-flex\">
\t\t\t\t\t\t\t\t<input class=\"form-control flex-grow-1 p-3\" type=\"search\" placeholder=\"Search for news\">
\t\t\t\t\t\t\t\t<button class=\"searchBtn p-3 ml-2\">Search</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-sm-12 col-md-12 mt-3 mt-md-0\">
\t\t\t\t\t\t\t<div class=\"tags text-white d-flex flex-wrap\">
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">All</p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">Article Long </p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">Read</p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">Video</p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">Opinion</p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">Interview</p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">Explainer</p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">First</p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">Person</p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">Exclusive</p>
\t\t\t\t\t\t\t\t<p class=\"mx-2 my-1\">Investigation</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<h5 class=\"p-3\">6 Results</h5>


\t\t\t\t<div class=\"col-lg-4 col-md-6 col-sm-4\">
\t\t\t\t\t<div class=\"articele-wrapper pb-5\">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/article1.png\" width=\"100%\">
\t\t\t\t\t\t<div class=\"d-flex mx-4 mt-2\">
\t\t\t\t\t\t\t<div class=\"offset-lg-0\">By Matthew Reyes </div>
\t\t\t\t\t\t\t<div class=\"offset-lg-1\">4 October, 2022</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"p-4 pt-0\">

\t\t\t\t\t\t\t<h6 class=\"pt-3 \"><b>Having overweight and depression can</b></h6>
\t\t\t\t\t\t\t<div>Lorem ipsum dolor sit amet,
\t\t\t\t\t\t\t\tconsectetur adipiscing elit, sed do
\t\t\t\t\t\t\t\teiusmod tempor incididunt ut labore
\t\t\t\t\t\t\t\tet dolore magna...
\t\t\t\t\t\t\t\t<button class=\"readMore p-2 float-start col-sm-7 mt-3\">Read More</button>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t\t<div class=\"col-lg-4 col-md-6 col-sm-4\">
\t\t\t\t\t<div class=\"articele-wrapper pb-5\">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/article2.png\" width=\"100%\">
\t\t\t\t\t\t<div class=\"d-flex mx-4 mt-2\">
\t\t\t\t\t\t\t<div class=\"offset-lg-0\">By Matthew Reyes </div>
\t\t\t\t\t\t\t<div class=\"offset-lg-1\">4 October, 2022</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"p-4 pt-0\">

\t\t\t\t\t\t\t<h6 class=\"pt-3 \"><b>Having overweight and depression can</b></h6>
\t\t\t\t\t\t\t<div>Lorem ipsum dolor sit amet,
\t\t\t\t\t\t\t\tconsectetur adipiscing elit, sed do
\t\t\t\t\t\t\t\teiusmod tempor incididunt ut labore
\t\t\t\t\t\t\t\tet dolore magna...
\t\t\t\t\t\t\t\t<button class=\"readMore p-2 float-start col-sm-7 mt-3\">Read More</button>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t\t<div class=\"col-lg-4 col-md-6 col-sm-4\">
\t\t\t\t\t<div class=\"articele-wrapper pb-5\">
\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/article3.png\" width=\"100%\">
\t\t\t\t\t\t<div class=\"d-flex mx-4 mt-2\">
\t\t\t\t\t\t\t<div class=\"offset-lg-0\">By Matthew Reyes </div>
\t\t\t\t\t\t\t<div class=\"offset-lg-1\">4 October, 2022</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"p-4 pt-0\">

\t\t\t\t\t\t\t<h6 class=\"pt-3 \"><b>Having overweight and depression can</b></h6>
\t\t\t\t\t\t\t<div>Lorem ipsum dolor sit amet,
\t\t\t\t\t\t\t\tconsectetur adipiscing elit, sed do
\t\t\t\t\t\t\t\teiusmod tempor incididunt ut labore
\t\t\t\t\t\t\t\tet dolore magna...
\t\t\t\t\t\t\t\t<button class=\"readMore p-2 float-start col-sm-7 mt-3\">Read More</button>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>







\t\t\t</div>

\t\t</div>
\t</section>



\t<section id=\"sec6\" class=\"p-2\">
\t\t<div class=\"container\">
\t\t\t<p class=\"text-center fs-5 pt-5\">Patient Experience</p>
\t\t\t<h2 class=\"text-center pb-4\">What patients say about the doctor</h2>
\t\t\t<div class=\"col-sm-12 border border-dark-subtle rounded p-4\">
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<input type=\"search\" class=\"p-3 col-sm-9\" placeholder=\"Patient Experience\">
\t\t\t\t\t<div class=\"col-sm-3 d-flex\"> <span class=\"pt-3\">Sort By: </span>
\t\t\t\t\t\t<div class=\"dropdown mx-2\">
\t\t\t\t\t\t\t<button type=\"button\" class=\"btn p-3 dropdown-toggle border border-dark-subtle\" data-bs-toggle=\"dropdown\">
\t\t\t\t\t\t\t\tMost Recent
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<ul class=\"dropdown-menu\">
\t\t\t\t\t\t\t\t<li><a class=\"dropdown-item\" href=\"#\">Normal</a></li>
\t\t\t\t\t\t\t\t<li><a class=\"dropdown-item active\" href=\"#\">Active</a></li>
\t\t\t\t\t\t\t\t<li><a class=\"dropdown-item disabled\" href=\"#\">Disabled</a></li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-sm-12 border border-dark-subtle rounded mt-5 pb-3 pt-3\">
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">All Patient Experiences</button>
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">brain checks</button>
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">proton therapy </button>
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\"> cancer and tumors</button>
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\"> craniosynostosis</button>
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">All Reviews </button>
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">brain checks </button>
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">proton therapy</button>
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">cancer and tumors</button>
\t\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">craniosynostosis</button>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<div class=\"row \">
\t\t\t\t<div class=\"col-sm-6 p-4\">
\t\t\t\t\t<div class=\"test-wrapp\">
\t\t\t\t\t\t<div class=\"p-3\">
\t\t\t\t\t\t\t<div class=\"quotes\">\"</div>
\t\t\t\t\t\t\t<b>I visited Neurological treatments</b><br>
\t\t\t\t\t\t\tAliquam fringilla nibh nec erat rhoncus, at sodales orci
\t\t\t\t\t\t\tmattis. Vestibulu ante ipsum primis in faucibus orci
\t\t\t\t\t\t\tluctus et ultrices posuere cubilia erp curae Cras
\t\t\t\t\t\t\tvolutpat fermentum ligula.

\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"col-sm-3\">
\t\t\t\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/testimonial1.png\" class=\"pt-2 img-fluid d-block mx-auto\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-6 pt-2\">
\t\t\t\t\t\t\t\t\t<div class=\"fw-bolder\">Weston R. James</div>
\t\t\t\t\t\t\t\t\t<button class=\"rel-btn p-2 m-2 btn\">Aneurysm</button>
\t\t\t\t\t\t\t\t\t<button class=\"rel-btn p-2 m-2 btn\">Hedeche</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"col-sm-6 p-4\">
\t\t\t\t\t<div class=\"test-wrapp\">
\t\t\t\t\t\t<div class=\"p-3\">
\t\t\t\t\t\t\t<div class=\"quotes\">\"</div>
\t\t\t\t\t\t\t<b>I visited Numbness </b><br>
\t\t\t\t\t\t\tAliquam fringilla nibh nec erat rhoncus, at sodales orci
\t\t\t\t\t\t\tmattis. Vestibulu ante ipsum primis in faucibus orci
\t\t\t\t\t\t\tluctus et ultrices posuere cubilia erp curae Cras
\t\t\t\t\t\t\tvolutpat fermentum ligula.

\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"col-sm-3\">
\t\t\t\t\t\t\t\t\t<img src=\"themes/custom/evolve/images/testimonial2.png\" class=\"pt-2 img-fluid d-block mx-auto\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-6 pt-2\">
\t\t\t\t\t\t\t\t\t<div class=\"fw-bolder\">Weston R. James</div>
\t\t\t\t\t\t\t\t\t<button class=\"rel-btn p-2 m-2 btn\">Aneurysm</button>
\t\t\t\t\t\t\t\t\t<button class=\"rel-btn p-2 m-2 btn\">Hedeche</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>


\t\t</div>
\t</section>

\t<section id=\"sec7\" class=\"pt-5 pb-5\">
\t\t<div class=\"container\">
\t\t\t<h2 class=\"text-center pb-5\">Frequently Asked Questions</h2>

\t\t\t<div class=\"col-sm-12 border border-dark-subtle rounded p-4\">
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<input type=\"search\" class=\"p-3 col-sm-9\" placeholder=\"Search For Answers\">
\t\t\t\t\t<div class=\"col-sm-3 d-flex\"> <span class=\"pt-3\">Sort By: </span>
\t\t\t\t\t\t<div class=\"dropdown mx-2\">
\t\t\t\t\t\t\t<button type=\"button\" class=\"btn p-3 dropdown-toggle border border-dark-subtle\" data-bs-toggle=\"dropdown\">
\t\t\t\t\t\t\t\tMost Recent
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<ul class=\"dropdown-menu\">
\t\t\t\t\t\t\t\t<li><a class=\"dropdown-item\" href=\"#\">Normal</a></li>
\t\t\t\t\t\t\t\t<li><a class=\"dropdown-item active\" href=\"#\">Active</a></li>
\t\t\t\t\t\t\t\t<li><a class=\"dropdown-item disabled\" href=\"#\">Disabled</a></li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
 
    
\t\t\t<div class=\"col-sm-12 border border-dark-subtle rounded p-3 mt-5\">
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">All Patient Experiences</button>
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">brain checks </button>
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">proton therapy</button>
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">cancer and tumors</button>
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">craniosynostosis</button>
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">All Reviews</button>
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">brain checks</button>
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">proton therapy</button>
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">cancer and tumors</button>
\t\t\t\t<button class=\"exp rounded-pill p-3 me-4 mt-3\">craniosynostosis</button>
\t\t\t\t
\t\t\t</div>

\t\t</div>
\t
\t</section>


\t<div class=\"pt-3\">
\t\t<iframe src=\"https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d15555.80884571165!2d77.59631594999999!3d12.91079305!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1712128342123!5m2!1sen!2sin\" class=\"map\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>
\t</div>

\t<script src=\"assets/js/main.js\"></script>
\t<script src=\"https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js\"></script>

</body>

</html>




";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "themes/custom/evolve/templates/page.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/evolve/templates/page.html.twig", "D:\\xampp\\htdocs\\lin\\linqmd\\themes\\custom\\evolve\\templates\\page.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array();
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                [],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
